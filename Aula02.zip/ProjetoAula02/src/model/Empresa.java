package model;

import dao.EmpresaDao;

public class Empresa 
{
   private int id;
   private String cnpj;
   private String razaoSocial;
   private Conjunto conjunto;
   private String temperatura;

   public Empresa()
   {
      this(0, "Sem cnpj", "Sem razão social", "-1",  null);
   }
	
   public Empresa(String cnpj, String razaoSocial, Conjunto conjunto)
   {
      this.setCnpj(cnpj);
      this.setRazaoSocial(razaoSocial);
      this.setConjunto(conjunto);
   }
	
   public Empresa(int id, String cnpj, String razaoSocial, String temperatura, Conjunto conjunto)
   {
      this.setId(id);
      this.setCnpj(cnpj);
      this.setRazaoSocial(razaoSocial);
      this.setTemperatura(temperatura);
      this.setConjunto(conjunto);
   }
	
   public String getTemperatura() {
      return temperatura;
   }

   public void setTemperatura(String temperatura) {
      this.temperatura = temperatura;
   }

   public int getId() {
      return id;
   }

   public String getCnpj() {
      return cnpj;
   }

   public String getRazaoSocial() {
      return razaoSocial;
   }
	
   public Conjunto getConjunto() {
      return conjunto;
   }

   public void setId(int id) {
      this.id = id;
   }

   public void setCnpj(String cnpj) {
      this.cnpj = cnpj;
   }

   public void setRazaoSocial(String razaoSocial) {
      this.razaoSocial = razaoSocial;
   }
	
   public void setConjunto(Conjunto conjunto) {
      this.conjunto = conjunto;
   }
	
   public String toString()
   {
      return  "ID: " + getId() + "\n" +
         	"CNPJ: " + getCnpj() + "\n" +
         	"Razão social" + getRazaoSocial() + "\n" +
         	"CONJUNTO: \n" + getConjunto();
   }
	
   public void criar(){
   	
      EmpresaDao dao = new EmpresaDao();
   	
   }
   public void atualizar(){
      EmpresaDao dao = new EmpresaDao();
   
   	
   }
   public void excluir(){
      EmpresaDao dao = new EmpresaDao();
   
   }
   public void carregar(){
      EmpresaDao dao = new EmpresaDao();
   
   }


}
