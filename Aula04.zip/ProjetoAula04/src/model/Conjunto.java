package model;

import dao.ConjuntoDao;


public class Conjunto 
{
   private int id;
   private String nome;
   private int andar;
	
   public Conjunto()
   {
      this(0, "Sem nome", 0);
   }
	
   public Conjunto(String nome, int andar)
   {
      this.setNome(nome);
      this.setAndar(andar);
   }
	
   public Conjunto(int id, String nome, int andar)
   {
      this.setId(id);
      this.setNome(nome);
      this.setAndar(andar);
   }

   public int getId() {
      return id;
   }

   public String getNome() {
      return nome;
   }

   public int getAndar() {
      return andar;
   }  

   public void setId(int id) {
      this.id = id;
   }

   public void setNome(String nome) {
      this.nome = nome;
   }

   public void setAndar(int andar) {
      this.andar = andar;
   }
   public void criar() 
   {   
      ConjuntoDao dao = new ConjuntoDao();
      dao.incluir(this);   
   };
   public void alterar() 	
   {   
      ConjuntoDao dao = new ConjuntoDao();
      dao.atualizar(this);
   }
   public void apagar() 
   {   
      ConjuntoDao dao = new ConjuntoDao(); 
      dao.excluir(this);
   }
   public Conjunto carregar() 
   {   
      ConjuntoDao dao = new ConjuntoDao(); 
      Conjunto conjunto = dao.carregar(this);
      return  conjunto ;
   
   }
   public String toString() {   
      return "Codigo: \t " + getId() +  " \n Nome \t " + getNome() + " \n Andar \t" + getAndar();
   } 
}

        
