package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import model.Empresa;

public class EmpresaDao {
	
	
   public void incluir( Empresa empresa){
   	
      Connection con = Connectionfactory.getConnection();
      PreparedStatement stm = null;
   
   	
   }
	
   public void excluir(){
   
      Connection con = Connectionfactory.getConnection();
      PreparedStatement stm = null;
   	
   }
	
   public void atualizar(){
   
      Connection con = Connectionfactory.getConnection();
      PreparedStatement stm = null;
   }

   public void carregar(){
   
      Connection con = Connectionfactory.getConnection();
      PreparedStatement stm = null;
   	 
   }
	 

}

