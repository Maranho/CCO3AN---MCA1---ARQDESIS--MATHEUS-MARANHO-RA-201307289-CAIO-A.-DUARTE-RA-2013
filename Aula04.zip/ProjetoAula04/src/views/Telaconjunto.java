package views;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import dao.ConjuntoDao;
import model.Conjunto;

import java.awt.Color;
import javax.swing.JOptionPane;

public class Telaconjunto extends JFrame implements ActionListener {

	private JButton btoConsu, btoEx, btoCadas, btoAlterar, btoSair, btoCar;
	private JTextField txtId, txtNome, txtAndar;
	private JLabel lbId, lbNome, lbAndar;

	public Telaconjunto() {

		super("Tela");
		Container cont = getContentPane();
		cont.setBackground(Color.lightGray);

		// criando os Labels
		lbId = new JLabel("Codigo:");
		lbNome = new JLabel("Nome:");
		lbAndar = new JLabel("Andar:");

		// criando os Campos;

		txtId = new JTextField(10);
		txtNome = new JTextField(10);
		txtAndar = new JTextField(10);

		// criando os Bot�es

		btoConsu = new JButton("Consultar");
		btoAlterar = new JButton("Alterar");
		btoCadas = new JButton("Cadastrar");
		btoEx = new JButton("Excluir");
		btoSair = new JButton("Sair");
		btoCar = new JButton("Carregar");

		setLayout(null);

		cont.add(lbId);
		cont.add(lbNome);
		cont.add(lbAndar);

		cont.add(txtId);
		cont.add(txtNome);
		cont.add(txtAndar);

		cont.add(btoCadas);
		cont.add(btoConsu);
		cont.add(btoAlterar);
		cont.add(btoEx);
		cont.add(btoSair);
		cont.add(btoCar);

		lbId.setBounds(30, 20, 150, 20);
		lbNome.setBounds(30, 50, 150, 20);
		lbAndar.setBounds(30, 80, 150, 20);

		txtId.setBounds(80, 20, 150, 20);
		txtNome.setBounds(80, 50, 150, 20);
		txtAndar.setBounds(80, 80, 150, 20);

		btoAlterar.setBounds(140, 120, 100, 20);
		btoCadas.setBounds(30, 120, 100, 20);
		btoConsu.setBounds(30, 150, 100, 20);
		btoEx.setBounds(140, 150, 100, 20);
		btoSair.setBounds(220, 240, 60, 20);
		btoCar.setBounds(80,180,100,20);
		btoCar.setEnabled(isDisplayable());

		btoSair.addActionListener(this);
		btoCadas.addActionListener(this);
		btoAlterar.addActionListener(this);
		btoEx.addActionListener(this);
		btoConsu.addActionListener(this);
		btoCar.addActionListener(this);
		btoCar.setVisible(true);
	}

	public void limparTela() {
		txtId.setText("");
		txtNome.setText("");
		txtAndar.setText("");

	}

	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == btoCadas) {

			Conjunto co = new Conjunto();
			ConjuntoDao dao = new ConjuntoDao();

			co.setId(Integer.parseInt(txtId.getText()));
			co.setNome(txtNome.getText());
			co.setAndar(Integer.parseInt(txtAndar.getText()));
			dao.incluir(co);
			JOptionPane.showMessageDialog(null, "cadastrando dados..... " + co.toString());

			limparTela();

		}
		if (e.getSource() == btoSair) {
			System.exit(0);
		}
		if (e.getSource() == btoEx) {
			Conjunto co = new Conjunto();
			ConjuntoDao dao = new ConjuntoDao();

			co.setId(Integer.parseInt(txtId.getText()));
			JOptionPane.showMessageDialog(null, "dados Excluidos" + co.toString());
			dao.excluir(co);
			System.out.println("apagado");
			limparTela();
		}
		if (e.getSource() == btoConsu) {

			Conjunto co = new Conjunto();
			ConjuntoDao dao = new ConjuntoDao();

			co.setId(Integer.parseInt(txtId.getText()));

			dao.carregar(co);

			txtNome.setText(co.getNome());
			String a = Integer.toString(co.getAndar());
			txtAndar.setText(a);

		}
		if (e.getSource() == btoAlterar) {

			Conjunto co = new Conjunto();
			ConjuntoDao dao = new ConjuntoDao();

			co.setId(Integer.parseInt(txtId.getText()));
			co.setNome(txtNome.getText());
			co.setAndar(Integer.parseInt(txtAndar.getText()));

			txtNome.setText(co.getNome());
			String a = Integer.toString(co.getAndar());
			txtAndar.setText(a);
			dao.atualizar(co);
		
			Object[] options = { "Sim", "N�o" };

			 JOptionPane.showOptionDialog(null, "Deseja Alterar ? \n" + co.toString(), "De novo?",
					JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]);

			if (options.equals("sim")) {
			
			   //  dao.atualizar(co);
				JOptionPane.showMessageDialog(null, "Atulizador com sucesso" + co.toString());


			} else {
				limparTela();
			}
		}

	}

	public static void main(String args[]) {

		Telaconjunto t = new Telaconjunto();
		t.setSize(300, 300);
		t.setLocationRelativeTo(null);
		t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		t.setVisible(true);

	}

}
