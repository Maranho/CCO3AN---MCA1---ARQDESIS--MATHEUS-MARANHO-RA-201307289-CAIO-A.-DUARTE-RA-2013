package service;

import dao.ConjuntoDao;

public class ConjuntoService {
	
	 ConjuntoDao dao ;
	 
	 public ConjuntoService(){
		 dao = new ConjuntoDao(); 
	 }
	 
	
}


	 


